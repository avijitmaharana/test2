import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './Users/Users.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule,MatInputModule } from '@angular/material';
import { UserServiceService } from './UserService.service';

@NgModule({
   declarations: [
      AppComponent,
      UsersComponent
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      HttpClientModule,
      MatExpansionModule,
      MatFormFieldModule,
      MatInputModule
   ],
   providers: [UserServiceService],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
