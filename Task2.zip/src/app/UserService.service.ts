import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class UserServiceService {

constructor(private http: HttpClient) { }
baseUrl = 'http://jsonplaceholder.typicode.com/users';

GetAllUsers(): Observable<any[]> {
 return this.http.get<any[]>(this.baseUrl);
}

}
