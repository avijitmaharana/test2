import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { UserServiceService } from '../UserService.service';

@Component({
  selector: 'app-Users',
  templateUrl: './Users.component.html',
  styleUrls: ['./Users.component.css']
})
export class UsersComponent implements OnInit {

  Users: any[] ;
  constructor(private service: UserServiceService) { }

  panelOpenState = false;

  step = 0;

  setStep(index: number) {
    this.step = index;
  }

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    this.service.GetAllUsers().subscribe((data) => {
      this.Users = data;
      console.log(this.Users);
    });
  }
}
